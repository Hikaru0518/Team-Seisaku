#include"DxLib.h"
#include"SceneMgr.h"
#include"Input.h"
#include"Player.h"
#include"GameSelection.h"

static int mImagePlayer;
static int Player1Stock = 0;
static int Player2Stock = 0;

void Player_Initialize() {
	mImagePlayer = LoadGraph("images/player.png");
	if (PlayerStock == 5) {
		Player1Stock = 5;
		Player2Stock = 5;
	}else if (PlayerStock == 10) {
		Player1Stock = 10;
		Player2Stock = 10;
	}
	else if (PlayerStock == 15) {
		Player1Stock = 15;
		Player2Stock = 15;
	}
	else if (PlayerStock == 20) {
		Player1Stock = 20;
		Player2Stock = 20;
	}
	else if (PlayerStock == 30) {
		Player1Stock = 30;
		Player2Stock = 30;
	}
}
void Player_Finalize() {
	DeleteGraph(mImagePlayer);
}
void Player_Update() {
	
}
void Player_Draw() {
	if (Player1Stock > 0) {
		DrawGraph(100, 100, mImagePlayer, TRUE);
	}
	if (Player2Stock > 0) {
		DrawGraph(500, 100, mImagePlayer, TRUE);
	}
	if (Player1Stock -= 1) {
		DrawGraph(100, 100, mImagePlayer, TRUE);
	}
	if (--Player2Stock -= 1) {
		DrawGraph(500, 100, mImagePlayer, TRUE);
	}
}