#include"DxLib.h"
#include"Input.h"
#include"SceneMgr.h"
#include"Stage.h"
#include"Stage1.h"
#include"Player.h"

static int mImageHandle;
static int HitBox;
static int Mountain;

void Stage1_Initialize() {
	mImageHandle = LoadGraph("images/Stage1/stage1.png");
	HitBox = LoadGraph("images/Stage1/jimen.png");
	Mountain = LoadGraph("images/Stage1/yama.png");
}
void Stage1_Finalize() {
	DeleteGraph(mImageHandle);
	DeleteGraph(HitBox);
	DeleteGraph(Mountain);
}
void Stage1_Draw() {
	DrawGraph(0, 0, mImageHandle, FALSE);
	DrawGraph(0, 414, HitBox, FALSE);
	Player_Draw();
	DrawGraph(0, 368, Mountain, TRUE);
}