#include"DxLib.h"
#include"SceneMgr.h"
#include"Input.h"
#include"GameSelection.h"

#define PI 3.1415926535897932384626433832795f

static int mImageHandle;
static int mImageMenu;
static int mImageCone;

static int Stock = 0;
static int mImageStock;

static int MenuNumber = 0;

void GameSelection_Initialize() {
	mImageHandle = LoadGraph("images/Scene_Game.png");
	mImageMenu = LoadGraph("images/menu.png");
	mImageCone = LoadGraph("images/cone.png");
	mImageStock = LoadGraph("images/Stock.png");
}

void GameSelection_Finalize() {
	DeleteGraph(mImageHandle);
	DeleteGraph(mImageMenu);
	DeleteGraph(mImageCone);
}

void GameSelection_Update() {
	if (iKeyFlg & PAD_INPUT_DOWN) {
		if (++MenuNumber > 1) MenuNumber = 0;
	}
	if (iKeyFlg & PAD_INPUT_UP) {
		if (--MenuNumber < 0) MenuNumber = 1;
	}

	if (iKeyFlg == PAD_INPUT_1) {
		switch (MenuNumber) {
		case 0:
			SceneMgr_ChangeScene(eScene_StockGame);
			break;
		case 1:
			SceneMgr_ChangeScene(eScene_TimeGame);
			break;
		}
		switch (Stock) {
		case 0:
			PlayerStock = 5;
			break;
		case 1:
			PlayerStock = 10;
			break;
		case 2:
			PlayerStock = 15;
			break;
		case 3:
			PlayerStock = 20;
			break;
		case 4:
			PlayerStock = 30;
			break;
		}
	}
	if (iKeyFlg & PAD_INPUT_RIGHT) {
		if (++Stock > 4) Stock = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--Stock < 0) Stock = 4;
		if (++Stock > 4) Stock = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--Stock < 0) Stock = 4;
	}
}

void GameSelection_Draw() {
	DrawGraph(0, 0, mImageHandle, FALSE);

	DrawGraph(0, -100, mImageStock, TRUE);
	DrawRotaGraph( 65+ Stock * 98,165,0.4f, PI / 2, mImageCone, TRUE);

	DrawGraph(120, 240, mImageMenu, TRUE);
	DrawRotaGraph(90, 260 + MenuNumber * 40, 0.7f, PI / 2, mImageCone, TRUE);
}