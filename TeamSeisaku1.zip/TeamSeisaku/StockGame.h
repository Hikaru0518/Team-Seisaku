#pragma once

void StockGame_Initialize();
void StockGame_Finalize();
void StockGame_Update();
void StockGame_Draw();
