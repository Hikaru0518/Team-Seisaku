#pragma once


static int PlayerStock = 0;

void GameSelection_Initialize();
void GameSelection_Finalize();
void GameSelection_Update();
void GameSelection_Draw();