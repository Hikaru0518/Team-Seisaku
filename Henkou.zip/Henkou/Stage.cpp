#include"DxLib.h"
#include"Input.h"
#include"SceneMgr.h"
#include"Stage.h"

#define PI 3.141592f

static int mImageHandle;

static int mImageStage_Desert;
static int mImageStage_Temple;
static int mImageStage_Dot;

static int mImageMenu;
static int mImageCone;

static int StageFlag = 0;

void Stage_Initialize() {
	mImageHandle = LoadGraph("images/Scene_Menu.png");

	mImageStage_Desert = LoadGraph("images/stage1.png");
	mImageStage_Temple = LoadGraph("images/stage2.png");
	mImageStage_Dot = LoadGraph("images/stage3.png");

	mImageCone = LoadGraph("images/cone.png");
}
void Stage_Finalize() {
	DeleteGraph(mImageHandle);
	DeleteGraph(mImageStage_Desert);
	DeleteGraph(mImageStage_Temple);
	DeleteGraph(mImageStage_Dot);
	DeleteGraph(mImageMenu);
	DeleteGraph(mImageCone);
}
void Stage_Update() {
	if (iKeyFlg & PAD_INPUT_RIGHT) {
		if (++StageFlag > 2) StageFlag = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--StageFlag < 0) StageFlag = 2;
		if (++StageFlag > 1) StageFlag = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--StageFlag < 0) StageFlag = 1;
	}

	if (iKeyFlg == PAD_INPUT_1) {
		switch (StageFlag) {
		case 0:
			SceneMgr_ChangeScene(eScene_GameSelection);
			break;
		case 1:
			SceneMgr_ChangeScene(eScene_GameSelection);
			break;
		case 2:
			SceneMgr_ChangeScene(eScene_GameSelection);
			break;
		}
	}
}
void Stage_Draw() {
	DrawGraph(0, 0, mImageHandle, FALSE);

	DrawGraph(30, 200, mImageStage_Desert, TRUE);
	DrawGraph(210, 200, mImageStage_Temple, TRUE);
	DrawGraph(390, 200, mImageStage_Dot, TRUE);

	DrawRotaGraph(20 + StageFlag * 180, 250, 0.4f, PI / 2, mImageCone, TRUE);
}