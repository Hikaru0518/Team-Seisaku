#include"StockGame.h"
#include"SceneMgr.h"
#include"DxLib.h"
#include"Player.h"
#include"Input.h"
#include"Stage.h"
#include"Stage1.h"

static int mImageHandle;

static int MenuNumber = 0;


void StockGame_Initialize() {
	//if(StageFlag==1)
	mImageHandle = LoadGraph("images/Stage1/stage1.png");
	Player_Initialize();
}
void StockGame_Finalize() {
	DeleteGraph(mImageHandle);

	Player_Finalize();
}
void StockGame_Update() {
	if ((CheckHitKey(KEY_INPUT_ESCAPE) != 0)) {
		SceneMgr_ChangeScene(eScene_Menu);//�V�[�������j���[�ɕύX
	}
	Player_Update();
}
void StockGame_Draw() {
	Player_Draw();
	DrawGraph(0, 0, mImageHandle, FALSE);

}