#pragma once

void Stage_Initialize();
void Stage_Finalize();
void Stage_Update();
void Stage_Draw();