#pragma once

void Player_Initialize();
void Player_Finalize();
void Player_Update();
void Player_Draw();