#include"DxLib.h"
#include"SceneMgr.h"
#include"Input.h"
#include"Player.h"
#include"GameSelection.h"
#include"StockSelect.h"

static int mImagePlayer;

static int Player1Stock = 0;
static int Player2Stock = 0;

void Player_Initialize() {
	mImagePlayer = LoadGraph("images/pleyer.png");
	
}
void Player_Finalize() {
	DeleteGraph(mImagePlayer);
}
void Player_Update() {
	
}
void Player_Draw() {
	if (Player1Stock > 0) {
		DrawGraph(100, 100, mImagePlayer, TRUE);
	}
	if (Player2Stock > 0) {
		DrawGraph(500, 100, mImagePlayer, TRUE);
	}
	if (Player1Stock -= 1) {
		DrawGraph(100, 100, mImagePlayer, TRUE);
	}
	if (Player2Stock -= 1) {
		DrawGraph(500, 100, mImagePlayer, TRUE);
	}
}