#pragma once

void TimeGame_Initialize();
void TimeGame_Finalize();
void TimeGame_Update();
void TimeGame_Draw();