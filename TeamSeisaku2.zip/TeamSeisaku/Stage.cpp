#include"DxLib.h"
#include"Input.h"
#include"SceneMgr.h"
#include"Stage.h"

#define PI 3.141592f

struct STAGE mStage;

static int mImageHandle;
static int mImageStage_Desert;
static int mImageStage_Temple;
static int mImageMenu;
static int mImageCone;

static int StageNumber = 0;
static int StageFlag = 0;

void Stage_Initialize() {
	mImageHandle = LoadGraph("images/StageSelection.jpg");

	mImageStage_Desert = LoadGraph("images/stage1.png");
	mImageStage_Temple = LoadGraph("images/stage2.png");

	mImageCone = LoadGraph("images/cone.png");
}
void Stage_Finalize() {
	DeleteGraph(mImageHandle);
	DeleteGraph(mImageStage_Desert);
	DeleteGraph(mImageStage_Temple);
	DeleteGraph(mImageMenu);
	DeleteGraph(mImageCone);
}
void Stage_Update() {
	if (iKeyFlg & PAD_INPUT_RIGHT) {
		if (++StageNumber > 1) StageNumber = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--StageNumber < 0) StageNumber = 1;
		if (++StageNumber > 1) StageNumber = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--StageNumber < 0) StageNumber = 1;
	}

	if (iKeyFlg == PAD_INPUT_1) {
		SceneMgr_ChangeScene(eScene_GameSelection);
		switch (StageNumber) {
		case 0:
			mStage.type = 1;
			break;
		case 1:
			mStage.type = 2;
			break;
		}
	}
}
void Stage_Draw() {
	DrawGraph(0, 0, mImageHandle, FALSE);

	DrawGraph(90, 200, mImageStage_Desert, TRUE);
	DrawGraph(350, 200, mImageStage_Temple, TRUE);

	DrawRotaGraph(60 + StageNumber * 270, 250, 0.4f, PI / 2, mImageCone, TRUE);
}