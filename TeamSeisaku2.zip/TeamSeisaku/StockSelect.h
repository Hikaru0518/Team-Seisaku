#pragma once

static int PlayerStock = 0;

void StockSelect_Initialize();
void StockSelect_Finalize();
void StockSelect_Update();
void StockSelect_Draw();