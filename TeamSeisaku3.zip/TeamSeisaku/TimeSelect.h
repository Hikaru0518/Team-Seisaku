#pragma once

static int StageTime = 0;

void TimeSelect_Initialize();
void TimeSelect_Finalize();
void TimeSelect_Update();
void TimeSelect_Draw();