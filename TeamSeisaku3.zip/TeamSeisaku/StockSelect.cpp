#include"DxLib.h"
#include"SceneMgr.h"
#include"Input.h"
#include"StockSelect.h"

#define PI 3.1415926535897932384626433832795f

static int Stock = 0;
static int mImageStock;
static int mImageCone;
static int mImageMenu;

void StockSelect_Initialize() {
	mImageCone = LoadGraph("images/cone.png");
	mImageStock = LoadGraph("images/Stock.png");
	mImageMenu = LoadGraph("images/Scene_Config.png");
}
void StockSelect_Finalize() {
	DeleteGraph(mImageCone);
	DeleteGraph(mImageStock);
}
void StockSelect_Update() {
	
if (iKeyFlg & PAD_INPUT_RIGHT) {
	if (++Stock > 4) Stock = 0;

}
if (iKeyFlg & PAD_INPUT_LEFT) {
	if (--Stock < 0) Stock = 4;
	if (++Stock > 4) Stock = 0;

}
if (iKeyFlg & PAD_INPUT_LEFT) {
	if (--Stock < 0)  Stock = 4;
}
if (iKeyFlg == PAD_INPUT_1) {
	SceneMgr_ChangeScene(eScene_StockGame);
	switch (Stock) {
	case 0:
		PlayerStock = 5;
		break;
	case 1:
		PlayerStock = 10;
		break;
	case 2:
		PlayerStock = 15;
		break;
	case 3:
		PlayerStock = 20;
		break;
	case 4:
		PlayerStock = 30;
		break;
	}
}
if ((CheckHitKey(KEY_INPUT_ESCAPE) != 0)) {
	SceneMgr_ChangeScene(eScene_Menu);//�V�[�������j���[�ɕύX
}
}
void StockSelect_Draw() {
	DrawGraph(0, 0, mImageMenu, TRUE);
	DrawGraph(0, -100, mImageStock, TRUE);
	DrawRotaGraph(65 + Stock * 98, 165, 0.4f, PI / 2, mImageCone, TRUE);
}