#include"StockGame.h"
#include"SceneMgr.h"
#include"DxLib.h"
#include"Player.h"
#include"Input.h"
#include"Stage.h"
#include"Stage1.h"
#include"Stage2.h"
#include"GameSelection.h"
#include"StockSelect.h"

static int Player1Stock = 0;
static int Player2Stock = 0;


void StockGame_Initialize() {

	if (mStage.type == 1) {
		Stage1_Initialize();
	}
	else if (mStage.type == 2) {
		Stage2_Initialize();
	}
	if (PlayerStock == 5) {
		Player1Stock = 5;
		Player2Stock = 5;
	}
	else if (PlayerStock == 10) {
		Player1Stock = 10;
		Player2Stock = 10;
	}
	else if (PlayerStock == 15) {
		Player1Stock = 15;
		Player2Stock = 15;
	}
	else if (PlayerStock == 20) {
		Player1Stock = 20;
		Player2Stock = 20;
	}
	else if (PlayerStock == 30) {
		Player1Stock = 30;
		Player2Stock = 30;
	}
	Player_Initialize();
}

void StockGame_Finalize() {
	if (mStage.type == 1) {
		Stage1_Finalize();
	}
	else if (mStage.type == 2) {
		Stage2_Finalize();
	}

	Player_Finalize();
}

void StockGame_Update() {
	if ((CheckHitKey(KEY_INPUT_ESCAPE) != 0)) {
		SceneMgr_ChangeScene(eScene_Menu);//�V�[�������j���[�ɕύX
	}
	Player_Update();
}

void StockGame_Draw() {

	if (mStage.type == 1) {
		Stage1_Draw();
	}
	else if (mStage.type == 2) {
		Stage2_Draw();
	}
	Player_Draw();
}