#pragma once


void GameSelection_Initialize();
void GameSelection_Finalize();
void GameSelection_Update();
void GameSelection_Draw();