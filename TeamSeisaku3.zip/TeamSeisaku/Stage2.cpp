#include"DxLib.h"
#include"Input.h"
#include"SceneMgr.h"
#include"Stage.h"
#include"Stage2.h"

static int mImageHandle;
static int HBCenter, HBGround_Right, HBGround_Left, HBRidge_Right, HBRidge_Left;
static int air[3];
static int Mountain;

void Stage2_Initialize() {
	HBGround_Right = LoadGraph("images/Stage2/Right_jimen.png");
	HBGround_Left = LoadGraph("images/Stage2/Left_jimen.png");
	HBRidge_Right = LoadGraph("images/Stage2/Right.png");
	HBRidge_Left = LoadGraph("images/Stage2/Left.png");
	HBCenter = LoadGraph("images/Stage2/center.png");
	mImageHandle = LoadGraph("images/Stage2/stage2.png");
	for (int i = 0; i < 3; i++) {
		air[i] = LoadGraph("images/Stage2/air.png");
	}
}
void Stage2_Finalize() {
	DeleteGraph(mImageHandle);
	DeleteGraph(HBCenter);
	DeleteGraph(HBGround_Right);
	DeleteGraph(HBGround_Left);
	DeleteGraph(HBRidge_Right);
	DeleteGraph(HBRidge_Left);
	for (int i = 0; i < 3; i++) {
		DeleteGraph(air[i]);
	}
}
void Stage2_Draw() {
	DrawGraph(0, 0, mImageHandle, FALSE);
	DrawGraph(229.5, 408, HBCenter, FALSE);
	DrawGraph(410, 427, HBGround_Right, FALSE);
	DrawGraph(47, 427, HBGround_Left, FALSE);
	DrawGraph(591, 78, HBRidge_Right, FALSE);
	DrawGraph(0, 78, HBRidge_Left, FALSE);
	DrawGraph(251, 190, air[0], FALSE);
	DrawGraph(0, 0, air[1], FALSE);
	DrawGraph(0, 0, air[2], FALSE);
}