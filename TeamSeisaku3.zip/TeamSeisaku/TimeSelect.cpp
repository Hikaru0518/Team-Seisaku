#include"DxLib.h"
#include"SceneMgr.h"
#include"Input.h"
#include"TimeSelect.h"

#define PI 3.1415926535897932384626433832795f

static int Time = 0;
static int mImageTime;
static int mImageCone;
static int mImageMenu;

void TimeSelect_Initialize() {
	mImageCone = LoadGraph("images/cone.png");
	mImageTime = LoadGraph("images/StageTime.png");
	mImageMenu = LoadGraph("images/Scene_Config.png");
}
void TimeSelect_Finalize() {
	DeleteGraph(mImageCone);
	DeleteGraph(mImageTime);
}
void TimeSelect_Update() {
	
	if (iKeyFlg & PAD_INPUT_RIGHT) {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
		if (++Time > 2) Time = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--Time < 0) Time = 2;
		if (++Time > 2) Time = 0;

	}
	if (iKeyFlg & PAD_INPUT_LEFT) {
		if (--Time < 0)  Time = 2;
	}
	if (iKeyFlg == PAD_INPUT_1) {
		SceneMgr_ChangeScene(eScene_TimeGame);
		switch (Time) {
		case 0:
			StageTime = 30;
			break;
		case 1:
			StageTime = 60;
			break;
		case 2:
			StageTime = 90;
			break;

		}
	}
	if ((CheckHitKey(KEY_INPUT_ESCAPE) != 0)) {
		SceneMgr_ChangeScene(eScene_Menu);//�V�[�������j���[�ɕύX
	}
}
void TimeSelect_Draw() {
	DrawGraph(0, 0, mImageMenu, FALSE);
	DrawGraph(0, -100, mImageTime, TRUE);
	DrawRotaGraph(80 + Time * 170, 170, 0.4f, PI / 2, mImageCone, TRUE);
}