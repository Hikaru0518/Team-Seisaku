#pragma once

void Stage1_Initialize();
void Stage1_Finalize();
void Stage1_Draw();