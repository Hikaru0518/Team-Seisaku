#include"TimeGame.h"
#include"Time.h"
#include"SceneMgr.h"
#include"DxLib.h"
#include"Player.h"
#include"Input.h"
#include "Stage.h"
#include"Stage1.h"
#include"Stage2.h"

static int MenuNumber = 0;

void TimeGame_Initialize() {
	if (mStage.type == 1) {
		Stage1_Initialize();
	}
	if (mStage.type == 2) {
		Stage2_Initialize();
	}
	Player_Initialize();
}

void TimeGame_Finalize() {
	if (mStage.type == 1) {
		Stage1_Finalize();
	}
	if (mStage.type == 2) {
		Stage2_Finalize();
	}
	Player_Finalize();
}

void TimeGame_Update() {
	if ((CheckHitKey(KEY_INPUT_ESCAPE) != 0)) {
		SceneMgr_ChangeScene(eScene_Menu);//�V�[�������j���[�ɕύX
	}
	Player_Update();
}

void TimeGame_Draw() {
	if (mStage.type == 1) {
		Stage1_Draw();
	}
	else if (mStage.type == 2) {
		Stage2_Draw();
	}
	Player_Draw();
}