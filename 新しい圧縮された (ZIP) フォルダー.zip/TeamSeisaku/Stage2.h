#pragma once

void Stage2_Initialize();
void Stage2_Finalize();
void Stage2_Draw();