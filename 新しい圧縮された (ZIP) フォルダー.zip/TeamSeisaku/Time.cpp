#include"Time.h"
#include"Player.h"

static int mGameTime;

void Time_Initialize() {
	mGameTime = 30;
}

void Time_Finalize() {
	if (mGameTime <= 0) {
		Player_Finalize();
	}
}

void Time_Update() {
	
}

void Time_Draw() {

}