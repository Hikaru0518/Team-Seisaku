#pragma once

void Time_Initialize();
void Time_Finalize();
void Time_Update();
void Time_Draw();