#include"Stock.h"

void Stock_Initialize() {

}

void Stock_Finalize() {

}

void Stock_Update() {

}

void Stock_Draw() {

}