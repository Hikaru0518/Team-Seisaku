#include"StockGame.h"
#include"SceneMgr.h"
#include"DxLib.h"
#include"Player.h"
#include"Input.h"
#include"Stage.h"
#include"Stage1.h"
#include"Stage2.h"

static int MenuNumber = 0;

void StockGame_Initialize() {
	if (mStage.type == 1) {
		Stage1_Initialize();
	}
	else if (mStage.type == 2) {
		Stage2_Initialize();
	}
	Player_Initialize();
}

void StockGame_Finalize() {
	if (mStage.type == 1) {
		Stage1_Finalize();
	}
	else if (mStage.type == 2) {
		Stage2_Finalize();
	}
	Player_Finalize();
}

void StockGame_Update() {
	if ((CheckHitKey(KEY_INPUT_ESCAPE) != 0)) {
		SceneMgr_ChangeScene(eScene_Menu);//�V�[�������j���[�ɕύX
	}
	Player_Update();
}

void StockGame_Draw() {
	if (mStage.type == 1) {
		Stage1_Draw();
	}
	else if (mStage.type == 2) {
		Stage2_Draw();
	}
}