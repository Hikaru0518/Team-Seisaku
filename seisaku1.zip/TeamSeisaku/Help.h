#pragma once

void Help_Initialize();
void Help_Finalize();
void Help_Update();
void Help_Draw();
