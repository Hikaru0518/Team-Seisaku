#pragma once

void Stage_Initialize();
void Stage_Finalize();
void Stage_Update();
void Stage_Draw();

struct STAGE {
	int type;
};

extern struct STAGE mStage;